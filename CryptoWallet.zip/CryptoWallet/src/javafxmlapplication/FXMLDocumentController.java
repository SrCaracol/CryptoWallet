/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxmlapplication;

import java.net.URL;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioMenuItem;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.ToggleGroup;

public class FXMLDocumentController implements Initializable {
    private Label labelMessage;
    @FXML
    private MenuItem mNueva;
    @FXML
    private MenuItem mSalir;
    @FXML
    private RadioMenuItem bitcoinSelected;
    @FXML
    private RadioMenuItem etherSelected;
    @FXML
    private RadioMenuItem litecoinSelected;
    @FXML
    private ListView<WalletEntry> listaWallet;
    @FXML
    private Label selectedCryptoDown;
    @FXML
    private Button bComprar;
    @FXML
    private Button bVender;
    @FXML
    private Label selectedCryptoUp;
    
    private ObservableList<WalletEntry> datos = null;
    @FXML
    private ToggleGroup cryptoToggleGroup;
    
    private WalletEntry Bitcoin = new WalletEntry("BitCoin", 0);
    private WalletEntry Ether = new WalletEntry("Ether", 0);
    private WalletEntry LiteCoin = new WalletEntry("LiteCoin", 0);
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        ArrayList<WalletEntry> misdatos = new ArrayList<WalletEntry>();
        datos = FXCollections.observableList(misdatos);
        datos = listaWallet.getItems();
        bVender.setDisable(true);
        
        
        
        bitcoinSelected.selectedProperty().addListener((a,b,c)->{
                if(Bitcoin.getCantidad() == 0){
                    bVender.setDisable(true);
                } else {
                    bVender.setDisable(false);
                }
        });
        
        
        etherSelected.selectedProperty().addListener((a,b,c)->{
                if(Ether.getCantidad() == 0){
                    bVender.setDisable(true);
                } else {
                    bVender.setDisable(false);
                }
        });
        
        
        litecoinSelected.selectedProperty().addListener((a,b,c)->{
                if(LiteCoin.getCantidad() == 0){
                    bVender.setDisable(true);
                } else {
                    bVender.setDisable(false);
                }
        });
        
        listaWallet.getSelectionModel().selectedItemProperty().addListener((a,b,c)->{
            if((listaWallet.getSelectionModel().getSelectedItem())==Bitcoin){
                cryptoToggleGroup.selectToggle(bitcoinSelected);
                selectedCryptoDown.setVisible(true);
                selectedCryptoUp.setVisible(true);
                selectedCryptoUp.setText("BitCoin");
                selectedCryptoDown.setText("Selected: BitCoin");
               
                
            }
            
            if((listaWallet.getSelectionModel().getSelectedItem())==Ether){
                cryptoToggleGroup.selectToggle(etherSelected);
                selectedCryptoDown.setVisible(true);
                selectedCryptoUp.setVisible(true);
                selectedCryptoUp.setText("Ether");
                selectedCryptoDown.setText("Selected: Ether");
                
                
            }
            
            if((listaWallet.getSelectionModel().getSelectedItem())==LiteCoin){
                cryptoToggleGroup.selectToggle(litecoinSelected);
                selectedCryptoDown.setVisible(true);
                selectedCryptoUp.setVisible(true);
                selectedCryptoUp.setText("LiteCoin");
                selectedCryptoDown.setText("Selected: LiteCoin");
                
            }
        });
        
        
    }    

    @FXML
    private void handleMNueva(ActionEvent event) {
        datos.clear(); 
    }

    @FXML
    private void handleMSalir(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    private void handleBComprar(ActionEvent event) {
        if(bitcoinSelected.isSelected()){
           TextInputDialog dialog = new TextInputDialog("");
           dialog.setTitle("Comprar");
           dialog.setHeaderText("Comprar BitCoin");
           dialog.setContentText("Introduce la cantidad ");
           Optional<String> result = dialog.showAndWait();
           if (result.isPresent()){
               if(Bitcoin.getCantidad() == 0){
                Bitcoin.setCantidad(Integer.parseInt(result.get()));
                datos.add(Bitcoin);
               }else{
                   datos.remove(Bitcoin);
                   Integer cantidadbitcoin = Bitcoin.getCantidad();
                   Bitcoin.setCantidad(cantidadbitcoin + Integer.parseInt(result.get()));
                   datos.add(Bitcoin);
               }
            }
        }
        
        if(etherSelected.isSelected()){
           TextInputDialog dialog = new TextInputDialog("");
           dialog.setTitle("Comprar");
           dialog.setHeaderText("Comprar Ether");
           dialog.setContentText("Introduce la cantidad ");
           Optional<String> result = dialog.showAndWait();
           if (result.isPresent()){
               if(Ether.getCantidad() == 0){
                Ether.setCantidad(Integer.parseInt(result.get()));
                datos.add(Ether);
               }else{
                   datos.remove(Ether);
                   Integer cantidadbitcoin = Ether.getCantidad();
                   Ether.setCantidad(cantidadbitcoin + Integer.parseInt(result.get()));
                   datos.add(Ether);
               }
            }
        }
        
        if(litecoinSelected.isSelected()){
           TextInputDialog dialog = new TextInputDialog("");
           dialog.setTitle("Comprar");
           dialog.setHeaderText("Comprar LiteCoin");
           dialog.setContentText("Introduce la cantidad ");
           Optional<String> result = dialog.showAndWait();
           if (result.isPresent()){
               if(LiteCoin.getCantidad() == 0){
                LiteCoin.setCantidad(Integer.parseInt(result.get()));
                datos.add(LiteCoin);
               }else{
                   datos.remove(LiteCoin);
                   Integer cantidadbitcoin = LiteCoin.getCantidad();
                   LiteCoin.setCantidad(cantidadbitcoin + Integer.parseInt(result.get()));
                   datos.add(LiteCoin);
               }
            }
        }
        
    }

    @FXML
    private void handleBVender(ActionEvent event) {
        
        if(litecoinSelected.isSelected() && LiteCoin.getCantidad()>0){
           TextInputDialog dialog = new TextInputDialog("");
           dialog.setTitle("Vender");
           dialog.setHeaderText("Vender LiteCoin");
           dialog.setContentText("Introduce la cantidad ");
           Optional<String> result = dialog.showAndWait();
           if (result.isPresent()){
               if((Integer.parseInt(result.get())) > (LiteCoin.getCantidad())){
                   Alert alert = new Alert(Alert.AlertType.ERROR);
                   alert.setTitle("Error");
                   alert.setHeaderText("Error en venta de Ether");
                   alert.setContentText("No hay " +result.get() +" unidades en el wallet" );
                   alert.showAndWait();
               }else{
                   datos.remove(LiteCoin);
                   Integer cantidadbitcoin = LiteCoin.getCantidad();
                   LiteCoin.setCantidad(cantidadbitcoin - Integer.parseInt(result.get()));
                   datos.add(LiteCoin);
               }
            }
        }
        
        
        if(etherSelected.isSelected() && Ether.getCantidad()>0){
           TextInputDialog dialog = new TextInputDialog("");
           dialog.setTitle("Vender");
           dialog.setHeaderText("Vender Ether");
           dialog.setContentText("Introduce la cantidad ");
           Optional<String> result = dialog.showAndWait();
           if (result.isPresent()){
               if((Integer.parseInt(result.get())) > (Ether.getCantidad())){
                   Alert alert = new Alert(Alert.AlertType.ERROR);
                   alert.setTitle("Error");
                   alert.setHeaderText("Error en venta de Ether");
                   alert.setContentText("No hay " +result.get() +" unidades en el wallet" );
                   alert.showAndWait();
               }else{
                   datos.remove(Ether);
                   Integer cantidadbitcoin = Ether.getCantidad();
                   Ether.setCantidad(cantidadbitcoin - Integer.parseInt(result.get()));
                   datos.add(Ether);
               }
            }
        }
        
        if(bitcoinSelected.isSelected() && Bitcoin.getCantidad()>0){
           TextInputDialog dialog = new TextInputDialog("");
           dialog.setTitle("Vender");
           dialog.setHeaderText("Vender BiteCoin");
           dialog.setContentText("Introduce la cantidad ");
           Optional<String> result = dialog.showAndWait();
           if (result.isPresent()){
               if((Integer.parseInt(result.get())) > (Bitcoin.getCantidad())){
                   Alert alert = new Alert(Alert.AlertType.ERROR);
                   alert.setTitle("Error");
                   alert.setHeaderText("Error en venta de BitCoin");
                   alert.setContentText("No hay " +result.get() +" unidades en el wallet" );
                   alert.showAndWait();
               }else{
                   datos.remove(Bitcoin);
                   Integer cantidadbitcoin = Bitcoin.getCantidad();
                   Bitcoin.setCantidad(cantidadbitcoin - Integer.parseInt(result.get()));
                   datos.add(Bitcoin);
               }
            }
        }
        
    }

    @FXML
    private void handleEther(ActionEvent event) { 
        selectedCryptoDown.setVisible(true);
        selectedCryptoUp.setVisible(true);
        selectedCryptoUp.setText("Ether");
        selectedCryptoDown.setText("Selected: Ether");      
    }

    @FXML
    private void handleLiteCoin(ActionEvent event) {
        selectedCryptoDown.setVisible(true);
        selectedCryptoUp.setVisible(true);
        selectedCryptoUp.setText("LiteCoin");
        selectedCryptoDown.setText("Selected: LiteCoin");  
    }

    @FXML
    private void handleBitcoin(ActionEvent event) {
        selectedCryptoDown.setVisible(true);
        selectedCryptoUp.setVisible(true);
        selectedCryptoUp.setText("BitCoin");
        selectedCryptoDown.setText("Selected: BitCoin");  
    }
    
}
